# Final Template Wiring Re-vet — 2026-08-20

## Scope

This release was rebuilt from the previously supplied `resume-factory-react-unified-premium-final-vetted.zip`.
The premium templates were audited against the normal template pipeline, with the goal of removing the separate premium runtime/markup/wrapper path.

## Verified architecture

1. The canonical registry is `src/data/templates.js` plus its generated synchronous mirror `public/js/template-system.js`.
2. All 95 template records use `rendererKind: "legacy"`.
3. 39 records are marked `premium` / `premium-sidebar`.
4. 40 former premium HTML fragments are now stored as `templateMarkup` on the canonical template records.
5. `src/data/premiumTemplates.js` is removed.
6. `public/css/premium-templates.css` is removed and its styling is merged into `public/css/styles.css`.
7. React no longer imports or initializes a premium-only registry.
8. `renderTemplateContent(data, tid)` resolves premium markup through the same synchronous `getTemplateDefinition(tid)` lookup used by the normal runtime.
9. `ResumeDocument.jsx` creates the same `<div class="page" data-template="...">` wrapper for every template.
10. No premium-only `rf-premium-root`, `isPremiumTemplate`, or `normalizePremiumFragment` path remains.
11. Gallery thumbnails call the same `renderTemplateContent()` path; there is no premium-only thumbnail registry.

## Premium fragment normalization

The audit found a specific structural defect in the sidebar group:

- `ivory-editorial-sidebar-02`
- `burgundy-two-page-04`
- `sand-modern-two-page-08`
- `teal-command-two-page-10`

Each contained a nested `.page` shell inside the premium `.cv` shell. Because the common renderer also creates the real `.page`, these templates could create a second page-like frame. Those nested `.page` wrappers were removed.

All 10 sidebar fragments formerly used `<main class="cv" ...>` as the outer shell while also containing nested `<main>` elements. The outer shell is now a `<div class="cv">`, making the fragment valid HTML and leaving the inner `<main>` elements to represent content regions.

The 10 sidebar fragments no longer carry an inner `data-template` identity. The only template identity is the canonical renderer-owned `.page[data-template]`.

The three formerly forced two-page sidebar specs no longer contain `pageCountSeed: 2`; page count is content-driven.

## CSS normalization

Premium root styles are scoped to `.page[data-template="..."]`.
No premium root retains:
- `width: 210mm`
- `min-height: 297mm`
- `margin: 0 auto 10mm`
- `overflow: hidden`

The renderer/A4 wrapper is the only owner of the A4 page boundary. Sidebar `.cv` frames use the available page content width and cannot become a second A4 sheet.

## Automated verification

`npm run qa:all` passed all stages:

- syntax
- dead-code
- template identity scope
- template registry
- unified renderer
- template wiring parity
- startup
- A4 page stack
- 95 page contracts
- contract activation
- pagination no-shrink
- overflow/reflow
- empty-page regression
- pagination structure
- premium root structure
- mobile A4
- strict mobile A4

Additional direct structural audit passed:

- 95 canonical template definitions
- 40 canonical premium HTML fragments
- 0 nested `.page` fragments among premium markup
- 0 nested `data-template` identities among premium markup
- 0 invalid outer `<main class="cv">` premium shells
- 0 premium-only renderer branches
- 0 legacy premium registry files
- 0 separate premium stylesheet files
- 0 premium root A4 geometry declarations remaining

## Runtime limitation

A Chromium runtime test was attempted against the exact source tree. Chromium in this execution environment aborts because its GPU process is unusable, so this release does not claim 95 fresh pixel screenshots or PDFs. The source, registry, DOM structure, pagination contracts and all automated regression checks were verified.
